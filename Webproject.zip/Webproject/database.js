// config/database.js
const { Sequelize } = require('sequelize');

const sequelize = new Sequelize({
  dialect: 'postgresql',
  host: 'localhost',
  username: 'postgres',
  password: 'postgres',
  database: 'todo_DB',
});

module.exports = sequelize;
