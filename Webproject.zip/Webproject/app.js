const express = require('express');
const bodyParser = require('body-parser');
const { sequelize } = require('./database'); // Make sure to adjust the path accordingly
const Item = require('./models/item');

const app = express();
const port = 3000;

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));

// Routes
app.get('/', async (req, res) => {
  try {
    const items = await Item.findAll();
    res.render('index', { items });
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/add', (req, res) => {
  res.render('add');
});

app.post('/add', async (req, res) => {
  try {
    const newItem = await Item.create({
      name: req.body.name,
    });
    res.redirect('/');
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/edit/:id', async (req, res) => {
  try {
    const itemId = parseInt(req.params.id);
    const itemToEdit = await Item.findByPk(itemId);
    res.render('edit', { item: itemToEdit });
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

app.post('/edit/:id', async (req, res) => {
  try {
    const itemId = parseInt(req.params.id);
    const itemToEdit = await Item.findByPk(itemId);
    itemToEdit.name = req.body.name;
    await itemToEdit.save();
    res.redirect('/');
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/delete/:id', async (req, res) => {
  try {
    const itemId = parseInt(req.params.id);
    const itemToDelete = await Item.findByPk(itemId);
    await itemToDelete.destroy();
    res.redirect('/');
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
